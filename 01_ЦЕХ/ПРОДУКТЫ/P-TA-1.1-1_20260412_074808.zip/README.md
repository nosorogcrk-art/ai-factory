# Telegram Keyword Monitor

Мониторит Telegram-каналы на наличие ключевых слов и отправляет алерты.

## Настройка

1. Создайте файл `.env`:
```
TELEGRAM_API_ID=your_api_id
TELEGRAM_API_HASH=your_api_hash
TELEGRAM_BOT_TOKEN=your_bot_token
TELEGRAM_ALERT_CHAT_ID=your_chat_id
```

2. Установите зависимости:
```bash
pip install -r requirements.txt
```

3. Запустите:
```bash
python main.py
```

Или через Docker:
```bash
docker build -t telegram-parser .
docker run --env-file .env telegram-parser
```