import os
from pyrogram import Client

class TelegramAlerter:
    def __init__(self):
        self.bot_token = os.getenv("TELEGRAM_BOT_TOKEN")
        self.chat_id = os.getenv("TELEGRAM_ALERT_CHAT_ID")
        
    async def send_alert(self, message):
        try:
            bot = Client("alert_bot", bot_token=self.bot_token)
            await bot.start()
            await bot.send_message(self.chat_id, f"🚨 Alert: {message}")
            await bot.stop()
            print(f"Alert sent: {message}")
            return True
        except Exception as e:
            print(f"Failed to send alert: {e}")
            return False