from fastapi import FastAPI
import asyncio
from telegram_client import TelegramClient
from filter import KeywordFilter
from alerter import TelegramAlerter

app = FastAPI()
telegram_client = None
keyword_filter = None
alerter = None

@app.on_event("startup")
async def startup_event():
    global telegram_client, keyword_filter, alerter
    telegram_client = TelegramClient()
    keyword_filter = KeywordFilter(["company", "startup", "funding"])
    alerter = TelegramAlerter()
    await telegram_client.start()
    asyncio.create_task(telegram_client.monitor_messages(keyword_filter, alerter))

@app.on_event("shutdown")
async def shutdown_event():
    if telegram_client:
        await telegram_client.stop()

@app.get("/health")
async def health():
    return {"status": "ok", "service": "Telegram Parser"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)