import asyncio
from pyrogram import Client, filters
import os

class TelegramClient:
    def __init__(self):
        self.api_id = os.getenv("TELEGRAM_API_ID")
        self.api_hash = os.getenv("TELEGRAM_API_HASH")
        self.client = None
        
    async def start(self):
        self.client = Client("telegram_parser", self.api_id, self.api_hash)
        await self.client.start()
        print("Telegram client started")
        
    async def stop(self):
        if self.client:
            await self.client.stop()
            print("Telegram client stopped")
            
    async def monitor_messages(self, keyword_filter, alerter):
        @self.client.on_message(filters.text)
        async def handle_message(client, message):
            if message.text and keyword_filter.matches(message.text):
                await alerter.send_alert(f"Keyword match in chat {message.chat.id}: {message.text[:100]}...")
                
        print("Started monitoring messages")