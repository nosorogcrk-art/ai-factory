import re

class KeywordFilter:
    def __init__(self, keywords):
        self.keywords = [k.lower() for k in keywords]
        
    def matches(self, text):
        text_lower = text.lower()
        for keyword in self.keywords:
            if keyword in text_lower:
                return True
        return False